import React from 'react';

// Very lightweight markdown renderer focused on chat capabilities
// Handles code blocks, bold, lists, and basic inline formatting
export function Markdown({ content }: { content: string }) {
  if (!content) return null;

  // Split by code blocks first
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <>
      {parts.map((part, index) => {
        // If it's a code block
        if (part.startsWith('```') && part.endsWith('```')) {
          const lines = part.split('\n');
          const language = lines[0].slice(3).trim();
          const code = lines.slice(1, -1).join('\n');
          
          return (
            <div key={index} className="my-4 rounded-md border border-border/50 overflow-hidden bg-muted/50">
              {language && (
                <div className="bg-muted px-4 py-1.5 text-[10px] uppercase font-mono text-muted-foreground border-b border-border/50">
                  {language}
                </div>
              )}
              <pre className="p-4 overflow-x-auto text-xs m-0 bg-transparent border-0">
                <code className="text-primary-foreground/90 bg-transparent p-0">
                  {code}
                </code>
              </pre>
            </div>
          );
        }

        // Parse inline formatting and blocks
        let processed = part;
        
        // Bold
        processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        
        // Italic
        processed = processed.replace(/\*(.*?)\*/g, '<em>$1</em>');
        processed = processed.replace(/_(.*?)_/g, '<em>$1</em>');
        
        // Inline code
        processed = processed.replace(/`([^`]+)`/g, '<code>$1</code>');
        
        // Split by lines to handle block elements like lists and paragraphs
        const lines = processed.split('\n');
        
        return (
          <div key={index} className="space-y-3">
            {lines.map((line, i) => {
              if (line.trim() === '') return <br key={i} className="hidden" />;
              
              // Lists
              if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
                return (
                  <li key={i} className="ml-4" dangerouslySetInnerHTML={{ __html: line.substring(2) }} />
                );
              }
              
              if (/^\d+\.\s/.test(line.trim())) {
                const text = line.trim().replace(/^\d+\.\s/, '');
                return (
                  <li key={i} className="ml-4 list-decimal" dangerouslySetInnerHTML={{ __html: text }} />
                );
              }
              
              // Headings
              if (line.startsWith('### ')) {
                return <h3 key={i} className="text-base font-semibold mt-4 mb-2" dangerouslySetInnerHTML={{ __html: line.substring(4) }} />;
              }
              if (line.startsWith('## ')) {
                return <h2 key={i} className="text-lg font-semibold mt-5 mb-2" dangerouslySetInnerHTML={{ __html: line.substring(3) }} />;
              }
              if (line.startsWith('# ')) {
                return <h1 key={i} className="text-xl font-bold mt-6 mb-3" dangerouslySetInnerHTML={{ __html: line.substring(2) }} />;
              }
              
              return <p key={i} className="m-0" dangerouslySetInnerHTML={{ __html: line }} />;
            })}
          </div>
        );
      })}
    </>
  );
}
