import { useState } from "react";
import { Sidebar } from "@/components/chat/Sidebar";
import { ChatArea } from "@/components/chat/ChatArea";

export default function Home() {
  const [activeId, setActiveId] = useState<number | null>(null);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-background text-foreground selection:bg-primary/30">
      <Sidebar activeId={activeId} onSelect={setActiveId} />
      <main className="flex-1 flex flex-col min-w-0 border-l border-border/50">
        <ChatArea activeId={activeId} onConversationCreated={setActiveId} />
      </main>
    </div>
  );
}
