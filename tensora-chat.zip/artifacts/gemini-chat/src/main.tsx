import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { setExtraHeaders } from "@workspace/api-client-react/src/custom-fetch";
import { getSessionId } from "./lib/session";

setExtraHeaders({ "X-Session-ID": getSessionId() });

createRoot(document.getElementById("root")!).render(<App />);
