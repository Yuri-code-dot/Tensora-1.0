import { useState, useRef, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Bot, User, Loader2 } from "lucide-react";
import { 
  useGetGeminiConversation, 
  useCreateGeminiConversation,
  getGetGeminiConversationQueryKey,
  getListGeminiConversationsQueryKey
} from "@workspace/api-client-react";
import { GeminiMessage } from "@workspace/api-client-react/src/generated/api.schemas";
import { ChatInput } from "./ChatInput";
import { ChatMessage } from "./ChatMessage";
import { getSessionId } from "@/lib/session";

interface ChatAreaProps {
  activeId: number | null;
  onConversationCreated: (id: number) => void;
}

export function ChatArea({ activeId, onConversationCreated }: ChatAreaProps) {
  const queryClient = useQueryClient();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [optimisticMessages, setOptimisticMessages] = useState<GeminiMessage[]>([]);
  const [streamingMessage, setStreamingMessage] = useState("");
  const [isStreaming, setIsStreaming] = useState(false);

  const { data: conversation, isLoading } = useGetGeminiConversation(
    activeId as number,
    { query: { enabled: !!activeId } }
  );

  const createMutation = useCreateGeminiConversation();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Keep scroll at bottom when messages change or streaming updates
  useEffect(() => {
    scrollToBottom();
  }, [conversation?.messages, optimisticMessages, streamingMessage, isStreaming]);

  // Reset local state when active conversation changes
  useEffect(() => {
    setOptimisticMessages([]);
    setStreamingMessage("");
    setIsStreaming(false);
  }, [activeId]);

  const handleSendMessage = async (content: string) => {
    if (!content.trim() || isStreaming) return;

    let targetId = activeId;

    // 1. Create conversation if none exists
    if (!targetId) {
      const titleWords = content.split(" ").slice(0, 4).join(" ");
      try {
        const newConv = await createMutation.mutateAsync({
          data: { title: titleWords + (content.split(" ").length > 4 ? "..." : "") }
        });
        targetId = newConv.id;
        onConversationCreated(newConv.id);
        queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
      } catch (err) {
        console.error("Failed to create conversation", err);
        return;
      }
    }

    if (!targetId) return;

    // 2. Add optimistic user message
    const tempUserMsg: GeminiMessage = {
      id: Date.now(),
      conversationId: targetId,
      role: "user",
      content,
      createdAt: new Date().toISOString()
    };
    
    setOptimisticMessages(prev => [...prev, tempUserMsg]);
    setIsStreaming(true);
    setStreamingMessage("");

    // 3. Start SSE Stream
    try {
      const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
      const res = await fetch(`${BASE}/api/gemini/conversations/${targetId}/messages`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Session-ID": getSessionId(),
        },
        body: JSON.stringify({ content }),
      });

      if (!res.ok) throw new Error("Failed to send message");

      const reader = res.body!.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        
        for (const line of lines) {
          if (!line.startsWith("data:")) continue;
          
          try {
            const dataStr = line.slice(5).trim();
            if (!dataStr) continue;
            
            const data = JSON.parse(dataStr);
            if (data.done) {
              break;
            }
            if (data.content) {
              setStreamingMessage(prev => prev + data.content);
            }
          } catch (e) {
            // Ignore parse errors for incomplete chunks
          }
        }
      }
    } catch (err) {
      console.error("Stream error:", err);
      // Let optimistic message stay, maybe show error state
    } finally {
      setIsStreaming(false);
      setStreamingMessage("");
      // Refetch to get actual DB messages
      queryClient.invalidateQueries({ queryKey: getGetGeminiConversationQueryKey(targetId) });
    }
  };

  const displayMessages = conversation ? conversation.messages : optimisticMessages;

  return (
    <div className="flex h-full flex-col bg-background/50 relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-primary/5 via-background to-background pointer-events-none -z-10" />
      
      <div className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-3xl p-4 md:p-6 pb-32">
          {isLoading && activeId ? (
            <div className="flex h-40 items-center justify-center">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : !activeId && displayMessages.length === 0 ? (
            <div className="flex h-[60vh] flex-col items-center justify-center text-center animate-in fade-in zoom-in duration-500">
              <div className="mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/20 shadow-[0_0_30px_rgba(139,92,246,0.15)]">
                <Bot className="h-8 w-8 text-primary" />
              </div>
              <h2 className="mb-2 text-2xl font-bold tracking-tight text-foreground">How can I help you today?</h2>
              <p className="max-w-sm text-sm text-muted-foreground">
                I'm your personal Gemini AI assistant. Fast, capable, and ready to work.
              </p>
            </div>
          ) : (
            <div className="flex flex-col gap-6">
              {displayMessages.map((msg, index) => (
                <ChatMessage 
                  key={msg.id} 
                  message={msg} 
                  delay={index >= (conversation?.messages.length || 0) ? 0 : index * 0.05}
                />
              ))}
              
              {/* Only show streaming optimistic user message if we don't have the conversation loaded yet */}
              {!activeId && optimisticMessages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} delay={0} />
              ))}

              {isStreaming && (
                <ChatMessage 
                  message={{ 
                    id: -1, 
                    conversationId: activeId || -1, 
                    role: "model", 
                    content: streamingMessage || "...", 
                    createdAt: new Date().toISOString() 
                  }}
                  isStreaming={true}
                  delay={0}
                />
              )}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          )}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-background via-background/95 to-transparent p-4 pt-10">
        <div className="mx-auto max-w-3xl relative">
          <ChatInput onSend={handleSendMessage} disabled={isStreaming} />
          <div className="mt-2 text-center text-[10px] text-muted-foreground font-medium tracking-wide opacity-50">
            AI-generated content may be incorrect.
          </div>
        </div>
      </div>
    </div>
  );
}
