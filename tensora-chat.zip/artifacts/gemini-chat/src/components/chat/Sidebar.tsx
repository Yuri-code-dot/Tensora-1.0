import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { format } from "date-fns";
import { MessageSquarePlus, Trash2, MessageSquare, Loader2 } from "lucide-react";
import { useListGeminiConversations, useDeleteGeminiConversation, getListGeminiConversationsQueryKey } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

interface SidebarProps {
  activeId: number | null;
  onSelect: (id: number | null) => void;
}

export function Sidebar({ activeId, onSelect }: SidebarProps) {
  const queryClient = useQueryClient();
  const { data: conversations, isLoading } = useListGeminiConversations();
  const deleteMutation = useDeleteGeminiConversation();

  const handleDelete = async (e: React.MouseEvent, id: number) => {
    e.stopPropagation();
    try {
      await deleteMutation.mutateAsync({ id });
      queryClient.invalidateQueries({ queryKey: getListGeminiConversationsQueryKey() });
      if (activeId === id) {
        onSelect(null);
      }
    } catch (err) {
      console.error("Failed to delete conversation", err);
    }
  };

  return (
    <div className="flex w-64 flex-col border-r border-sidebar-border bg-sidebar text-sidebar-foreground transition-all duration-300 md:w-80 flex-shrink-0 h-full">
      <div className="flex h-16 shrink-0 items-center justify-between px-4 border-b border-sidebar-border">
        <span className="font-semibold text-lg flex items-center gap-2 tracking-tight">
          <div className="w-6 h-6 rounded bg-primary/20 flex items-center justify-center text-primary border border-primary/30 shadow-[0_0_10px_rgba(139,92,246,0.2)]">
            <MessageSquare className="w-3.5 h-3.5" />
          </div>
          Gemini
        </span>
      </div>

      <div className="p-3">
        <Button
          onClick={() => onSelect(null)}
          className="w-full justify-start gap-2 bg-sidebar-accent/50 hover:bg-sidebar-accent text-sidebar-accent-foreground border border-sidebar-border shadow-sm font-medium transition-all"
          variant="outline"
          size="sm"
        >
          <MessageSquarePlus className="w-4 h-4" />
          New Chat
        </Button>
      </div>

      <ScrollArea className="flex-1 px-3">
        <div className="flex flex-col gap-1 pb-4">
          {isLoading ? (
            <div className="flex items-center justify-center p-4 text-muted-foreground">
              <Loader2 className="w-5 h-5 animate-spin opacity-50" />
            </div>
          ) : conversations?.length === 0 ? (
            <div className="text-center p-4 text-xs text-muted-foreground italic">
              No conversations yet.
            </div>
          ) : (
            conversations?.map((conv) => (
              <button
                key={conv.id}
                onClick={() => onSelect(conv.id)}
                className={cn(
                  "group relative flex w-full flex-col items-start gap-1 rounded-lg p-3 text-left text-sm transition-all hover:bg-sidebar-accent",
                  activeId === conv.id
                    ? "bg-sidebar-accent text-sidebar-accent-foreground shadow-sm ring-1 ring-sidebar-border"
                    : "text-muted-foreground hover:text-sidebar-foreground"
                )}
              >
                <div className="flex w-full items-start justify-between gap-2">
                  <span className="truncate font-medium flex-1">
                    {conv.title || "New Conversation"}
                  </span>
                  <span className="shrink-0 text-[10px] opacity-60">
                    {format(new Date(conv.createdAt), "MMM d")}
                  </span>
                </div>
                <div className="text-[11px] opacity-60 truncate w-[85%]">
                  {format(new Date(conv.createdAt), "h:mm a")}
                </div>

                <Button
                  variant="ghost"
                  size="icon"
                  className={cn(
                    "absolute right-2 top-1/2 -translate-y-1/2 h-7 w-7 opacity-0 transition-opacity hover:bg-destructive/10 hover:text-destructive focus-visible:opacity-100",
                    "group-hover:opacity-100"
                  )}
                  onClick={(e) => handleDelete(e, conv.id)}
                  disabled={deleteMutation.isPending}
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span className="sr-only">Delete</span>
                </Button>
              </button>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}
