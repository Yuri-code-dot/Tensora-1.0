import { Router } from "express";
import conversationsRouter from "./conversations";
import imageRouter from "./image";

const router = Router();

router.use(conversationsRouter);
router.use(imageRouter);

export default router;
