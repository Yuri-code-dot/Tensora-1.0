import { Bot, User } from "lucide-react";
import { GeminiMessage } from "@workspace/api-client-react/src/generated/api.schemas";
import { cn } from "@/lib/utils";
import { Markdown } from "./Markdown";

interface ChatMessageProps {
  message: GeminiMessage;
  isStreaming?: boolean;
  delay?: number;
}

export function ChatMessage({ message, isStreaming, delay = 0 }: ChatMessageProps) {
  const isUser = message.role === "user";

  return (
    <div 
      className={cn(
        "group flex w-full animate-in fade-in slide-in-from-bottom-4 fill-mode-both duration-500",
        isUser ? "justify-end" : "justify-start"
      )}
      style={{ animationDelay: `${delay}s` }}
    >
      <div className={cn(
        "flex max-w-[85%] items-start gap-4",
        isUser ? "flex-row-reverse" : "flex-row"
      )}>
        <div className={cn(
          "flex h-8 w-8 shrink-0 items-center justify-center rounded-md border shadow-sm",
          isUser 
            ? "border-primary/20 bg-primary text-primary-foreground" 
            : "border-border/50 bg-card text-foreground shadow-md"
        )}>
          {isUser ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4 text-primary" />}
        </div>

        <div className={cn(
          "relative flex flex-col gap-1 rounded-2xl px-5 py-3.5 text-sm shadow-sm",
          isUser 
            ? "bg-primary text-primary-foreground rounded-tr-sm" 
            : "bg-card border border-border/50 text-card-foreground rounded-tl-sm"
        )}>
          {/* Subtle glow for AI messages */}
          {!isUser && (
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
          )}
          
          <div className={cn(
            "prose prose-sm max-w-none relative z-10 leading-relaxed",
            isUser ? "prose-invert text-primary-foreground" : "dark:prose-invert"
          )}>
            {isUser ? (
              <p className="whitespace-pre-wrap m-0">{message.content}</p>
            ) : (
              <>
                <Markdown content={message.content} />
                {isStreaming && message.content === "..." && (
                  <span className="inline-flex gap-1 ml-1">
                    <span className="animate-bounce delay-75">.</span>
                    <span className="animate-bounce delay-150">.</span>
                    <span className="animate-bounce delay-300">.</span>
                  </span>
                )}
                {isStreaming && message.content !== "..." && (
                  <span className="inline-block w-1.5 h-4 ml-1 bg-primary align-middle animate-pulse" />
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
